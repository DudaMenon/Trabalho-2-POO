package org.example.strategy;

public class CalculadoraDesconto {
    private DescontoStrategy estrategia;

    // qual estratégia será usada no  cálculo
    public void setEstrategia(DescontoStrategy estrategia) {
        this.estrategia = estrategia;
    }

    public double calcular(double valorOriginal) {
        if (estrategia == null) {
            return valorOriginal; // Se nenhuma estratégia foi definida, retorna o valor normal
        }
        return estrategia.calcularPrecoFinal(valorOriginal);
    }
}