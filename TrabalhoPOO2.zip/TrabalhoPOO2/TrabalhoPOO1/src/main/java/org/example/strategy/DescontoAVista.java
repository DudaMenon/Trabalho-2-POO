package org.example.strategy;

public class DescontoAVista implements DescontoStrategy {
    @Override
    public double calcularPrecoFinal(double valorOriginal) {
        // 10%
        return valorOriginal * 0.90;
    }
}