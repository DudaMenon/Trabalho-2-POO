package org.example.modelo.dao;

import org.example.modelo.conexao.Conexao;
import org.example.modelo.entidades.ItemVenda;
import org.example.modelo.entidades.Produto;
import org.example.modelo.entidades.Venda;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VendaDAO {

    public void finalizarVenda(Venda venda) {
        String sqlVenda = "INSERT INTO venda (valor_total) VALUES (?)";
        String sqlItem = "INSERT INTO item_venda (venda_id, produto_id, quantidade_vendida, preco_unitario) VALUES (?, ?, ?, ?)";
        String sqlAtualizaEstoque = "UPDATE produto SET quantidade = quantidade - ? WHERE id = ?";

        Connection conn = null;
        try {
            conn = Conexao.conectar();
            conn.setAutoCommit(false); // Inicia a transação com segurança

            try (PreparedStatement stmtVenda = conn.prepareStatement(sqlVenda, Statement.RETURN_GENERATED_KEYS)) {
                stmtVenda.setDouble(1, venda.getValorTotal());
                stmtVenda.executeUpdate();

                try (ResultSet rs = stmtVenda.getGeneratedKeys()) {
                    if (rs.next()) {
                        venda.setId(rs.getInt(1));
                    }
                }
            }

            try (PreparedStatement stmtItem = conn.prepareStatement(sqlItem);
                 PreparedStatement stmtEstoque = conn.prepareStatement(sqlAtualizaEstoque)) {

                for (ItemVenda item : venda.getItens()) {
                    stmtItem.setInt(1, venda.getId());
                    stmtItem.setInt(2, item.getProduto().getId());
                    stmtItem.setInt(3, item.getQuantidadeVendida());
                    stmtItem.setDouble(4, item.getPrecoUnitario());
                    stmtItem.executeUpdate();

                    stmtEstoque.setInt(1, item.getQuantidadeVendida());
                    stmtEstoque.setInt(2, item.getProduto().getId());
                    stmtEstoque.executeUpdate();
                }
            }

            conn.commit(); // Confirma tudo se correr bem
            System.out.println("Venda registada com sucesso! ID da Venda: " + venda.getId());

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Reverte se houver erro
                    System.out.println("Erro na venda. Transação cancelada.");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            System.out.println("Erro ao finalizar venda: " + e.getMessage());
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public List<Venda> listar() {
        List<Venda> vendas = new ArrayList<>();
        String sqlVendas = "SELECT * FROM venda ORDER BY id DESC";

        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sqlVendas);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Venda v = new Venda();
                v.setId(rs.getInt("id"));
                v.setValorTotal(rs.getDouble("valor_total"));

                // Busca e preenche os itens associados a esta venda para fazer sentido com o valor total
                v.setItens(buscarItensDaVenda(conn, v.getId()));

                vendas.add(v);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar vendas: " + e.getMessage());
        }

        return vendas;
    }

    private List<ItemVenda> buscarItensDaVenda(Connection conn, int vendaId) {
        List<ItemVenda> itens = new ArrayList<>();
        String sqlItens = "SELECT iv.*, p.nome as produto_nome, p.preco as produto_preco " +
                "FROM item_venda iv " +
                "JOIN produto p ON iv.produto_id = p.id " +
                "WHERE iv.venda_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sqlItens)) {
            stmt.setInt(1, vendaId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    ItemVenda item = new ItemVenda();
                    item.setId(rs.getInt("id"));
                    item.setQuantidadeVendida(rs.getInt("quantidade_vendida"));
                    item.setPrecoUnitario(rs.getDouble("preco_unitario"));

                    Produto p = new Produto();
                    p.setId(rs.getInt("produto_id"));
                    p.setNome(rs.getString("produto_nome"));
                    p.setPreco(rs.getDouble("produto_preco"));

                    item.setProduto(p);
                    itens.add(item);
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao buscar itens da venda: " + e.getMessage());
        }
        return itens;
    }
}