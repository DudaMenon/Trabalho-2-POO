package org.example.observer;

import org.example.modelo.entidades.Produto;
import java.util.ArrayList;
import java.util.List;

public class GerenciadorEstoque {
    private List<ObservadorEstoque> observadores = new ArrayList<>();

    public void adicionarObservador(ObservadorEstoque observador) {
        observadores.add(observador);
    }

    public void removerObservador(ObservadorEstoque observador) {
        observadores.remove(observador);
    }

    public void verificarEstoque(Produto produto) {
        // Se o stock estiver menor ou igual a 5 unidades, dispara o alerta
        if (produto.getQuantidade() <= 5) {
            for (ObservadorEstoque obs : observadores) {
                obs.atualizar(produto);
            }
        }
    }
}