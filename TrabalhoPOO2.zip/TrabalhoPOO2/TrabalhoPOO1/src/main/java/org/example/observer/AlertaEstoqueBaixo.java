package org.example.observer;

import javafx.application.Platform;
import javafx.scene.control.Alert;
import org.example.modelo.entidades.Produto;

public class AlertaEstoqueBaixo implements ObservadorEstoque {
    @Override
    public void atualizar(Produto produto) {

        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso de Stock Baixo");
            alert.setHeaderText("Produto em falta!");
            alert.setContentText("O produto '" + produto.getNome() +
                    "' está com stock baixo! Quantidade atual: " + produto.getQuantidade());
            alert.showAndWait();
        });
    }
}