package org.example.factory;

import org.example.modelo.entidades.Produto;
import org.example.modelo.entidades.Categoria;

public class CartaFactory extends ProdutoFactory {
    @Override
    public Produto criarProduto(String nome, double preco, int quantidade) {
        Produto produto = new Produto();
        produto.setNome(nome);
        produto.setPreco(preco);
        produto.setQuantidade(quantidade);

        // Define automaticamente a categoria de cartas (ex: ID 1 para TCG)
        Categoria categoria = new Categoria();
        categoria.setId(1);
        categoria.setNome("Cartas TCG");
        produto.setCategoria(categoria);

        return produto;
    }
}