package org.example.factory;

import org.example.modelo.entidades.Produto;
import org.example.modelo.entidades.Categoria;

public class AcessorioFactory extends ProdutoFactory {
    @Override
    public Produto criarProduto(String nome, double preco, int quantidade) {
        Produto produto = new Produto();
        produto.setNome(nome);
        produto.setPreco(preco);
        produto.setQuantidade(quantidade);

        // Define automaticamente a categoria de acessórios (ex: ID 2 para Acessórios/Sleeves)
        Categoria categoria = new Categoria();
        categoria.setId(2);
        categoria.setNome("Acessórios");
        produto.setCategoria(categoria);

        return produto;
    }
}