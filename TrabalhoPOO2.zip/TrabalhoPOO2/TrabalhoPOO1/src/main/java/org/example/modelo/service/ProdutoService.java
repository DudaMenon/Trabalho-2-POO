package org.example.modelo.service;

import org.example.factory.AcessorioFactory;
import org.example.factory.CartaFactory;
import org.example.factory.ProdutoFactory;
import org.example.modelo.dao.ProdutoDAO;
import org.example.modelo.entidades.Produto;

import java.util.List;

public class ProdutoService {

    private ProdutoDAO produtoDAO;
    public ProdutoService() {
        this.produtoDAO = new ProdutoDAO();
    }
    public void cadastrarProduto(String tipo, String nome, double preco, int quantidade) {
        ProdutoFactory factory;

        if (tipo != null && tipo.equalsIgnoreCase("ACESSORIO")) {
            factory = new AcessorioFactory();
            System.out.println("[Factory Method] A usar AcessorioFactory");
        } else {
            factory = new CartaFactory();
            System.out.println("[Factory Method] A usar CartaFactory");
        }

        Produto produto = factory.criarProduto(nome, preco, quantidade);
        produtoDAO.inserir(produto);
    }
    public List<Produto> listarProdutos() {
        return produtoDAO.listar();
    }

    public void atualizarProduto(Produto produto) throws Exception {
        if (produto.getId() <= 0) {
            throw new IllegalArgumentException("ID inválido para atualização.");
        }
        produtoDAO.atualizar(produto);
    }

    public void excluirProduto(int id) throws Exception {
        if (id <= 0) {
            throw new IllegalArgumentException("ID inválido para exclusão.");
        }
        produtoDAO.excluir(id);
    }
}