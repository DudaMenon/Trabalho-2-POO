package org.example.modelo.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.modelo.entidades.Categoria;
import org.example.modelo.entidades.ItemVenda;
import org.example.modelo.entidades.Produto;
import org.example.modelo.entidades.Venda;
import org.example.modelo.service.ProdutoService;
import org.example.modelo.service.VendaService;
import org.example.strategy.CalculadoraDesconto;
import org.example.strategy.DescontoAVista;
import org.example.strategy.SemDesconto;

import java.util.ArrayList;
import java.util.List;

public class ProdutoController {

    @FXML private TextField txtNome;
    @FXML private TextField txtPreco;
    @FXML private TextField txtQuantidade;
    @FXML private TextField txtCategoriaId;
    @FXML private ComboBox<String> cmbTipoProduto;
    @FXML private TextField txtQtdVenda;
    @FXML private CheckBox chkPagamentoAVista;
    @FXML private Label lblResumoValores;

    @FXML private TableView<Produto> tabelaProdutos;
    @FXML private TableColumn<Produto, String> colNome;
    @FXML private TableColumn<Produto, Double> colPreco;
    @FXML private TableColumn<Produto, Integer> colQuantidade;
    @FXML private TableColumn<Produto, String> colCategoria;

    @FXML private TableView<ItemVenda> tabelaCarrinho;
    @FXML private TableColumn<ItemVenda, String> colCarrinhoNome;
    @FXML private TableColumn<ItemVenda, Integer> colCarrinhoQtd;
    @FXML private TableColumn<ItemVenda, Double> colCarrinhoSubtotal;

    @FXML private Button btnIrParaHistorico;

    private ProdutoService produtoService = new ProdutoService();
    private VendaService vendaService = new VendaService();
    private ObservableList<Produto> listaProdutos;
    private ObservableList<ItemVenda> listaCarrinho = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        if (cmbTipoProduto != null) {
            cmbTipoProduto.getItems().addAll("CARTA", "ACESSORIO", "TABULEIRO");
            cmbTipoProduto.setValue("CARTA");
        }

        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colPreco.setCellValueFactory(new PropertyValueFactory<>("preco"));
        colQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
        colCategoria.setCellValueFactory(cellData -> {
            Categoria cat = cellData.getValue().getCategoria();
            return new javafx.beans.property.SimpleStringProperty(cat != null ? cat.getNome() : "");
        });

        colCarrinhoNome.setCellValueFactory(cellData -> {
            ItemVenda item = cellData.getValue();
            String nome = (item.getProduto() != null) ? item.getProduto().getNome() : "";
            return new javafx.beans.property.SimpleStringProperty(nome);
        });
        colCarrinhoQtd.setCellValueFactory(new PropertyValueFactory<>("quantidadeVendida"));
        colCarrinhoSubtotal.setCellValueFactory(cellData -> {
            ItemVenda item = cellData.getValue();
            double sub = item.getQuantidadeVendida() * item.getPrecoUnitario();
            return new javafx.beans.property.SimpleObjectProperty<>(sub);
        });

        tabelaCarrinho.setItems(listaCarrinho);
        carregarTabela();

        tabelaProdutos.getSelectionModel().selectedItemProperty().addListener((obs, antigo, novo) -> {
            if (novo != null) {
                txtNome.setText(novo.getNome());
                txtPreco.setText(String.valueOf(novo.getPreco()));
                txtQuantidade.setText(String.valueOf(novo.getQuantidade()));
                if (novo.getCategoria() != null) {
                    txtCategoriaId.setText(String.valueOf(novo.getCategoria().getId()));
                }
            }
        });
    }

    public void carregarTabela() {
        try {
            List<Produto> produtosFromDb = produtoService.listarProdutos();
            if (produtosFromDb != null) {
                listaProdutos = FXCollections.observableArrayList(produtosFromDb);
                tabelaProdutos.setItems(listaProdutos);
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    @FXML
    private void handleInserir() {
        try {
            String nome = txtNome.getText();
            double preco = Double.parseDouble(txtPreco.getText());
            int quantidade = Integer.parseInt(txtQuantidade.getText());
            String tipoEscolhido = (cmbTipoProduto != null && cmbTipoProduto.getValue() != null) ? cmbTipoProduto.getValue() : "CARTA";

            produtoService.cadastrarProduto(tipoEscolhido, nome, preco, quantidade);
            carregarTabela();
            showAlert("Sucesso", "Produto criado com sucesso!", Alert.AlertType.INFORMATION);
            limparCampos();
        } catch (Exception e) {
            showAlert("Erro", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleAtualizar() {
        Produto selecionado = tabelaProdutos.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            showAlert("Aviso", "Selecione um produto na tabela.", Alert.AlertType.WARNING);
            return;
        }

        try {
            selecionado.setNome(txtNome.getText());
            selecionado.setPreco(Double.parseDouble(txtPreco.getText()));
            selecionado.setQuantidade(Integer.parseInt(txtQuantidade.getText()));

            if (txtCategoriaId != null && !txtCategoriaId.getText().isEmpty()) {
                Categoria cat = new Categoria();
                cat.setId(Integer.parseInt(txtCategoriaId.getText()));
                selecionado.setCategoria(cat);
            }

            produtoService.atualizarProduto(selecionado);
            carregarTabela();
            showAlert("Sucesso", "Produto atualizado com sucesso!", Alert.AlertType.INFORMATION);
        } catch (Exception e) {
            showAlert("Erro", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleExcluir() {
        Produto selecionado = tabelaProdutos.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            showAlert("Aviso", "Selecione um produto na tabela.", Alert.AlertType.WARNING);
            return;
        }

        try {
            produtoService.excluirProduto(selecionado.getId());
            carregarTabela();
            showAlert("Sucesso", "Produto excluído com sucesso!", Alert.AlertType.INFORMATION);
        } catch (Exception e) {
            showAlert("Erro", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleAdicionarAoCarrinho() {
        try {
            Produto selecionado = tabelaProdutos.getSelectionModel().getSelectedItem();
            if (selecionado == null) {
                showAlert("Aviso", "Selecione um produto na tabela para adicionar ao carrinho.", Alert.AlertType.WARNING);
                return;
            }

            if (txtQtdVenda == null || txtQtdVenda.getText().isEmpty()) {
                showAlert("Aviso", "Informe a quantidade.", Alert.AlertType.WARNING);
                return;
            }

            int qtd = Integer.parseInt(txtQtdVenda.getText());
            if (qtd <= 0 || qtd > selecionado.getQuantidade()) {
                showAlert("Erro", "Quantidade inválida ou superior ao estoque.", Alert.AlertType.ERROR);
                return;
            }

            ItemVenda item = new ItemVenda();
            item.setProduto(selecionado);
            item.setQuantidadeVendida(qtd);
            item.setPrecoUnitario(selecionado.getPreco());

            listaCarrinho.add(item);
            txtQtdVenda.clear();
            atualizarCalculosTela();
        } catch (Exception e) {
            showAlert("Erro", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleLimparCarrinho() {
        listaCarrinho.clear();
        atualizarCalculosTela();
    }

    @FXML
    public void atualizarCalculosTela() {
        double subtotal = 0.0;
        for (ItemVenda item : listaCarrinho) {
            subtotal += (item.getQuantidadeVendida() * item.getPrecoUnitario());
        }

        CalculadoraDesconto calc = new CalculadoraDesconto();
        boolean aVista = (chkPagamentoAVista != null && chkPagamentoAVista.isSelected());
        if (aVista) {
            calc.setEstrategia(new DescontoAVista());
        } else {
            calc.setEstrategia(new SemDesconto());
        }

        double totalFinal = calc.calcular(subtotal);
        double desconto = subtotal - totalFinal;

        if (lblResumoValores != null) {
            lblResumoValores.setText(String.format("Subtotal: R$ %.2f | Desconto (Strategy): R$ %.2f | Total Final: R$ %.2f", subtotal, desconto, totalFinal));
        }
    }

    @FXML
    private void handleFinalizarVendaCarrinho() {
        try {
            if (listaCarrinho.isEmpty()) {
                showAlert("Aviso", "O carrinho está vazio.", Alert.AlertType.WARNING);
                return;
            }

            double subtotal = 0.0;
            for (ItemVenda item : listaCarrinho) {
                subtotal += (item.getQuantidadeVendida() * item.getPrecoUnitario());
            }

            Venda venda = new Venda();
            venda.setItens(new ArrayList<>(listaCarrinho));
            venda.setValorTotal(subtotal);

            boolean pagamentoAVista = (chkPagamentoAVista != null && chkPagamentoAVista.isSelected());
            vendaService.finalizarVendaComPadroes(venda, pagamentoAVista);

            carregarTabela();
            showAlert("Sucesso", "Venda finalizada com sucesso!\nValor final pago: R$ " + venda.getValorTotal(), Alert.AlertType.INFORMATION);

            listaCarrinho.clear();
            if (chkPagamentoAVista != null) chkPagamentoAVista.setSelected(false);
            atualizarCalculosTela();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erro", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void abrirHistorico(ActionEvent event) {
        try {
            List<Venda> vendas = vendaService.listarVendas();
            TableView<Venda> tabela = new TableView<>();

            TableColumn<Venda, Integer> colId = new TableColumn<>("ID Venda");
            colId.setCellValueFactory(new PropertyValueFactory<>("id"));
            colId.setPrefWidth(70);

            TableColumn<Venda, Double> colValor = new TableColumn<>("Valor Total (R$)");
            colValor.setCellValueFactory(new PropertyValueFactory<>("valorTotal"));
            colValor.setPrefWidth(120);

            TableColumn<Venda, String> colItens = new TableColumn<>("Itens, Qtd, Preço Unitário e Subtotal");
            colItens.setCellValueFactory(cellData -> {
                Venda v = cellData.getValue();
                if (v.getItens() != null && !v.getItens().isEmpty()) {
                    String descricaoItens = v.getItens().stream().map(item -> {
                        String nomeProd = (item.getProduto() != null) ? item.getProduto().getNome() : "Produto";
                        double subtotal = item.getQuantidadeVendida() * item.getPrecoUnitario();
                        return nomeProd + " [Qtd: " + item.getQuantidadeVendida() + " x R$ " + item.getPrecoUnitario() + " = R$ " + subtotal + "]";
                    }).collect(java.util.stream.Collectors.joining("; "));
                    return new javafx.beans.property.SimpleStringProperty(descricaoItens);
                }
                return new javafx.beans.property.SimpleStringProperty("Nenhum item registado");
            });
            colItens.setPrefWidth(530);

            tabela.getColumns().addAll(colId, colValor, colItens);
            if (vendas != null) {
                tabela.setItems(FXCollections.observableArrayList(vendas));
            }

            Button btnVoltar = new Button("Voltar para Estoque");
            btnVoltar.setOnAction(e -> {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/view/produto_view.fxml"));
                    Parent root = loader.load();
                    Stage stage = (Stage) btnVoltar.getScene().getWindow();
                    stage.setScene(new Scene(root));
                    stage.setTitle("Gestão de Produtos - Hobby Store");
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });

            VBox layout = new VBox(15, new Label("Validação do Histórico de Vendas"), tabela, btnVoltar);
            layout.setAlignment(Pos.CENTER);
            layout.setPadding(new Insets(20));

            Stage stage = (Stage) btnIrParaHistorico.getScene().getWindow();
            stage.setScene(new Scene(layout, 750, 550));
            stage.setTitle("Histórico de Vendas - Hobby Store");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erro", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void limparCampos() {
        txtNome.clear();
        txtPreco.clear();
        txtQuantidade.clear();
        if (txtCategoriaId != null) txtCategoriaId.clear();
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}