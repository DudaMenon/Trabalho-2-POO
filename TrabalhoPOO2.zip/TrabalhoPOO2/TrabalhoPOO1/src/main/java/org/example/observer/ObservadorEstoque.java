package org.example.observer;

import org.example.modelo.entidades.Produto;

public interface ObservadorEstoque {
    void atualizar(Produto produto);
}