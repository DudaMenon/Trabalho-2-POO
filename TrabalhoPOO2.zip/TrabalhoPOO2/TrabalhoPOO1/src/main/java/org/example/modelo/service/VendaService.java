package org.example.modelo.service;

import org.example.modelo.dao.VendaDAO;
import org.example.modelo.entidades.ItemVenda;
import org.example.modelo.entidades.Venda;
import org.example.observer.AlertaEstoqueBaixo;
import org.example.observer.GerenciadorEstoque;
import org.example.strategy.CalculadoraDesconto;
import org.example.strategy.DescontoAVista;
import org.example.strategy.SemDesconto;

import java.util.List;

public class VendaService {

    private VendaDAO vendaDAO;
    private CalculadoraDesconto calculadoraDesconto;
    private GerenciadorEstoque gerenciadorEstoque;

    public VendaService() {
        this.vendaDAO = new VendaDAO();
        this.calculadoraDesconto = new CalculadoraDesconto();
        this.gerenciadorEstoque = new GerenciadorEstoque();
        this.gerenciadorEstoque.adicionarObservador(new AlertaEstoqueBaixo());
    }

    public List<Venda> listarVendas() {
        return vendaDAO.listar();
    }

    public void finalizarVendaComPadroes(Venda venda, boolean pagamentoAVista) throws Exception {
        if (venda.getItens() == null || venda.getItens().isEmpty()) {
            throw new IllegalArgumentException("A venda não possui itens.");
        }

        // padrão Strategy
        if (pagamentoAVista) {
            calculadoraDesconto.setEstrategia(new DescontoAVista());
            System.out.println("[Strategy Ativo] Aplicando Desconto à Vista");
        } else {
            calculadoraDesconto.setEstrategia(new SemDesconto());
            System.out.println("[Strategy Ativo] Aplicando Sem Desconto");
        }

        double valorBruto = venda.getValorTotal();
        double valorComDesconto = calculadoraDesconto.calcular(valorBruto);
        venda.setValorTotal(valorComDesconto);
        vendaDAO.finalizarVenda(venda);

        // Verificação de estoque após venda
        for (ItemVenda item : venda.getItens()) {
            int quantidadeRestante = item.getProduto().getQuantidade() - item.getQuantidadeVendida();
            item.getProduto().setQuantidade(quantidadeRestante);
            gerenciadorEstoque.verificarEstoque(item.getProduto());
        }
    }
}