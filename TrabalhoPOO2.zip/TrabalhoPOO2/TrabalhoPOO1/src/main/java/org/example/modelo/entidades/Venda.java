package org.example.modelo.entidades;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Venda {
    private int id;
    private Date dataVenda;
    private double valorTotal;
    private List<ItemVenda> itens = new ArrayList<>();

    public Venda() {
    }

    public Venda(int id, Date dataVenda, double valorTotal) {
        this.id = id;
        this.dataVenda = dataVenda;
        this.valorTotal = valorTotal;
    }

    public void adicionarItem(ItemVenda item) {
        this.itens.add(item);
        this.valorTotal += item.getQuantidadeVendida() * item.getPrecoUnitario();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(Date dataVenda) {
        this.dataVenda = dataVenda;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public List<ItemVenda> getItens() {
        return itens;
    }

    public void setItens(List<ItemVenda> itens) {
        this.itens = itens;
        // Recalcula o total caso a lista seja substituída
        this.valorTotal = 0;
        if (itens != null) {
            for (ItemVenda item : itens) {
                this.valorTotal += item.getQuantidadeVendida() * item.getPrecoUnitario();
            }
        }
    }
}