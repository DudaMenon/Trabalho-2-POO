package org.example.modelo.controller;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.example.modelo.entidades.ItemVenda;
import org.example.modelo.entidades.Produto;
import org.example.modelo.entidades.Venda;
import org.example.modelo.service.VendaService;

import java.util.ArrayList;
import java.util.List;

public class VendaController {

    @FXML private TextField txtProdutoId;
    @FXML private TextField txtQuantidadeVendida;
    @FXML private CheckBox chkPagamentoAVista;
    @FXML private Label lblValorTotal;

    @FXML private TableView<ItemVenda> tabelaItensVenda;
    @FXML private TableColumn<ItemVenda, String> colNomeProduto;
    @FXML private TableColumn<ItemVenda, Integer> colQtd;
    @FXML private TableColumn<ItemVenda, Double> colSubtotal;

    @FXML private Button btnVoltar;

    private VendaService vendaService = new VendaService();
    private List<ItemVenda> itensVendaTemp = new ArrayList<>();
    private double valorBrutoTotal = 0.0;

    @FXML
    public void initialize() {
        if (colNomeProduto != null) {
            colNomeProduto.setCellValueFactory(cellData -> {
                ItemVenda item = cellData.getValue();
                String nome = (item.getProduto() != null) ? item.getProduto().getNome() : "Produto";
                return new javafx.beans.property.SimpleStringProperty(nome);
            });
        }
        if (colQtd != null) {
            colQtd.setCellValueFactory(new PropertyValueFactory<>("quantidadeVendida"));
        }
        if (colSubtotal != null) {
            colSubtotal.setCellValueFactory(new PropertyValueFactory<>("precoUnitario"));
        }
    }

    @FXML
    private void handleAdicionarItem() {
        try {
            int prodId = Integer.parseInt(txtProdutoId.getText());
            int qtd = Integer.parseInt(txtQuantidadeVendida.getText());

            Produto prod = new Produto();
            prod.setId(prodId);
            prod.setNome("Produto ID " + prodId);
            prod.setPreco(50.0); // Valor base para teste
            prod.setQuantidade(15); // Estoque simulado para testar o Observer

            ItemVenda item = new ItemVenda();
            item.setProduto(prod);
            item.setQuantidadeVendida(qtd);
            item.setPrecoUnitario(prod.getPreco());

            itensVendaTemp.add(item);
            valorBrutoTotal += (prod.getPreco() * qtd);

            if (tabelaItensVenda != null) {
                tabelaItensVenda.setItems(FXCollections.observableArrayList(itensVendaTemp));
            }

            if (lblValorTotal != null) {
                lblValorTotal.setText(String.format("Total: R$ %.2f", valorBrutoTotal));
            }

            txtProdutoId.clear();
            txtQuantidadeVendida.clear();
        } catch (Exception e) {
            showAlert("Erro", "Erro ao adicionar item: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleFinalizarVenda() {
        try {
            if (itensVendaTemp.isEmpty()) {
                showAlert("Aviso", "Adicione itens à venda antes de finalizar.", Alert.AlertType.WARNING);
                return;
            }

            Venda venda = new Venda();
            venda.setItens(itensVendaTemp);
            venda.setValorTotal(valorBrutoTotal);

            // Lê a CheckBox: aqui o Strategy decide se aplica desconto ou não
            boolean pagamentoAVista = (chkPagamentoAVista != null && chkPagamentoAVista.isSelected());

            // Executa a venda com os padrões aplicados (Strategy + Observer)
            vendaService.finalizarVendaComPadroes(venda, pagamentoAVista);

            if (lblValorTotal != null) {
                String estrategiaNome = pagamentoAVista ? "Desconto à Vista (Strategy)" : "Sem Desconto";
                lblValorTotal.setText(String.format("Finalizado [%s]: R$ %.2f", estrategiaNome, venda.getValorTotal()));
            }

            showAlert("Venda Concluída",
                    "Venda registada com sucesso!\nValor final com Strategy: R$ " + venda.getValorTotal(),
                    Alert.AlertType.INFORMATION);

            itensVendaTemp.clear();
            valorBrutoTotal = 0.0;
            if (tabelaItensVenda != null) tabelaItensVenda.getItems().clear();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erro", "Erro ao finalizar venda: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleVoltarEstoque(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/view/produto_view.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnVoltar.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Gestão de Produtos - Hobby Store");
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert("Erro", "Não foi possível voltar: " + ex.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}