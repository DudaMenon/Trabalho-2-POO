package org.example.factory;

import org.example.modelo.entidades.Produto;

public abstract class ProdutoFactory {
    // que as subclasses vão implementar
    public abstract Produto criarProduto(String nome, double preco, int quantidade);
}