package org.example.strategy;

public interface DescontoStrategy {
    double calcularPrecoFinal(double valorOriginal);
}