package org.example.strategy;

public class SemDesconto implements DescontoStrategy {
    @Override
    public double calcularPrecoFinal(double valorOriginal) {
        return valorOriginal; // Sem alteração no valor
    }
}