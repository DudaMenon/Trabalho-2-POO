package org.example.modelo.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.example.modelo.entidades.Venda;
import org.example.modelo.service.VendaService;

import java.io.IOException;
import java.util.List;

public class HistoricoController {

    @FXML private TableView<Venda> tabelaHistorico;
    @FXML private TableColumn<Venda, Integer> colIdVenda;
    @FXML private TableColumn<Venda, Double> colValorTotal;
    @FXML private Button btnVoltarEstoque;

    private VendaService vendaService = new VendaService();
    private ObservableList<Venda> listaVendas;

    @FXML
    public void initialize() {
        colIdVenda.setCellValueFactory(new PropertyValueFactory<>("id"));
        colValorTotal.setCellValueFactory(new PropertyValueFactory<>("valorTotal"));

        carregarHistorico();
    }

    public void carregarHistorico() {
        try {
            List<Venda> vendasFromDb = vendaService.listarVendas();
            if (vendasFromDb != null) {
                listaVendas = FXCollections.observableArrayList(vendasFromDb);
                tabelaHistorico.setItems(listaVendas);
            }
        } catch (Exception e) {
            System.err.println("Erro ao carregar histórico de vendas: " + e.getMessage());
        }
    }

    @FXML
    private void voltarParaEstoque(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/view/produto_view.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) btnVoltarEstoque.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Gestão de Produtos - Hobby Store");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}